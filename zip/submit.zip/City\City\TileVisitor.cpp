#include "stdafx.h"
#include "TileVisitor.h"


CTileVisitor::CTileVisitor()
{
}


CTileVisitor::~CTileVisitor()
{
}

